<section class="workout container">
    <div class="title">movement</div>
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <p>Хай, <?=$data?>, давай зарядимося позитивною енергією. Виконаємо декілька фізичних вправ разом з нашим
                    роботом.
                    Підіймай руки як показано на ілюстрації. Організм вже почав вироблення дофаміну.
                </p>
                <video src=/images/move/Project 1.avi"></video>
            </div>
            <div class="carousel-item"><p><?=$data?>, виконуємо розминку сидячи на підлозі або навіть дивані. Але головне не
                    заснути на дивані</p>

                <img class="d-block " src="/images/move/1 (2).png" alt="Second slide">
            </div>
            <div class="carousel-item"><p>Іван сидів дві години і його поперек вже втомився. Виконуй вправи за роботом,
                    щоб не боліла спина.</p>

                <img class="d-block" src="/images/move/1 (3).png" alt="Third slide">
            </div>
            <div class="carousel-item"><p>Сова вміє кружляти шиєю на 360 градусів. А ми розминаємо шию разом з Ванею.
                </p>

                <img class="d-block " src="/images/move/1 (4).png" alt=" slide">
            </div>
            <div class="carousel-item"><p>Стрибаємо в ритмі гепарда і закінчуємо нашу маленьку розминку. Дякуємо що
                    зробив це разом з нашим роботом Іваном.
                </p>

                <img class="d-block " src="/images/move/1 (5).png" alt=" slide">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</section>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
