
<form class="change" action="train" method="post">
    <div>
        <input type="radio" id="contactChoice1"
               name="workout" value="set1">
        <label for="contactChoice1">Набір вправ №1</label>

        <input type="radio" id="contactChoice2"
               name="workout" value="set2">
        <label for="contactChoice2">Набір вправ №2</label>

        <input type="radio" id="contactChoice3"
               name="workout" value="set3">
        <label for="contactChoice3">Набір вправ №3</label>

        <input type="radio" id="contactChoice3"
               name="workout" value="set4">
        <label for="contactChoice3">Набір вправ №4</label>
    </div>
    <div>
        <button type="submit">Submit</button>
        <img class="img_start" src="/images/робот.png" alt="">

    </div>
</form>